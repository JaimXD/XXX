<?php
include 'User.php';
$username = "";
$password = "";
$logResult = "";
$classState = "";

if ($_SERVER['REQUEST_METHOD'] == 'POST'&& isset($_POST['username'])) {
    $username = $_POST['username'];
    $password = $_POST['password'];

    $user = new User($username, $password);

    if ($user->validation()){
        $logResult = "Login successful. Welcome, " . $username . "!";
        $classState = "exito";
    } else {
        $logResult = "Login failed. Invalid username or password.";
        $classState = "error";
    }
}

?>