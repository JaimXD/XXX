<?php

$number = "";
$factorial = "";
$facResult = "";

if($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['facNum'])){
    $number = $_POST['facNum'];
    if ($number == null || $number < 0) {
        $facResult = "Error: Please enter a non-negative number";
        return;
    } else {
        $factorial = 1;
    }

    for ($i =1; $i<= $number; $i++){
        $factorial *= $i;
    }
    
    $facResult = "Factorial of " . $number . " is: " . $factorial;
}
?>