function login(){
    const username = document.getElementById("username").value;
    const password = document.getElementById("password").value;
    const resultElement = document.getElementById("logResult");

    let user = new UserX (username, password);

    if(user.validation()){
        resultElement.style.color = "green";
        resultElement.innerText = "Login Successful!";
    } else {
        resultElement.style.color = "red";
        resultElement.innerText = "Login Failed: Invalid username or password.";
    }
}