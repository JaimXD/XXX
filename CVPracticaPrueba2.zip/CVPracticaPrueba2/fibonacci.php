<?php

$number = "";
$fibresult = "";
$fib = [0, 1]; 

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['fibNum'])) {
    $number = $_POST['fibNum'];

    if ($number == null || $number <= 0) {
        $fibresult = "Error: Please enter a number greater than 0";
        return;
    }

    for ($i = 2; $i < $number; $i++){
        $fib[$i] = $fib[$i - 1] + $fib[$i - 2];
    }

    $fibresult = implode(", ", array_slice($fib, 0, $number));
}
?>