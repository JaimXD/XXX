class UserX {
    constructor(user, pass){
        this.username = user;
        this.password = pass; 
    }

    validation(){
        if(this.username === "admin" && this.password === "123"){
            return true;
        } else {
            return false;
        }

    }

}