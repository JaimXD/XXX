function factorial(){
    const number = parseInt(document.getElementById("facNum").value);
    const resultElement = document.getElementById('facResult');
    let result;

    resultElement.style.color = "#333";

    if (isNaN(number || number < 0)){
        resultElement.style.color = "red";
        resultElement.innerText = "Error: Please enter a non-negative integer";
        return;
    } else {
        result = 1;
    }

    for (let i=1; i <= number; i++){
        result *= i;
    }

    resultElement.innerText = "Factorial of:"+ number + " is " + result;
}