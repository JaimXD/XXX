function CalculateFibonacci(){
    const number = parseFloat(document.getElementById("fibNum").value);
    const resultElement = document.getElementById("fibResult");
    let sequence = [0, 1];

    resultElement.style.color = "#333"

    if(isNaN(number) || number <= 0){
        resultElement.style.color = "red";
        resultElement.innerText = "Error: Please enter or a number greater than 0";
        return;
    }

    for(let i = 2; i < number; i++){
        sequence[i] = sequence[i - 1] +sequence[i -2];
    }

    resultElement.innerText = "Fibonacci Sequence: " + sequence.slice(0, number).join(", ");


}