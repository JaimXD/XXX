function Calculate(){
    const num1 = parseFloat(document.getElementById("num1").value);
    const num2 = parseFloat(document.getElementById("num2").value);
    const operation = document.getElementById("operation").value;
    const resultElement = document.getElementById("result");
    let result;

    resultElement.style.color = "#333";

    switch(operation){
        case "add":
            result = num1 + num2;
            break;
        case "subtract":
            result = num1 - num2;
            break;
        case "multiply":
            result = num1 * num2;
            break;
        case "divide":
            if(num2 !== 0){
                result = num1 / num2;
            } else {
                result = "Error: Division by zero";
                resultElement.style.color = "red";
            }
            break;
        default:
            result = "Error: Invalid operation";
    }

    resultElement.innerText = "Result: " + result;
}