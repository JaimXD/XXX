<?php include 'operaciones.php';
include 'fibonacci.php';
include 'factorial.php';
include 'login.php';
?>

<!DOCTYPE html>
<html>
    <head>
        <link rel="stylesheet" href="style.css">
    </head>
    <body>
        <h1>Practica Prueba de Computacion Visual - PHP</h1>
        <h2>Operaciones</h2>
        <form method="post" action="">
            <input type="text" name="num1" placeholder="Enter a number" required>
            <select name="operation">
                <option value="add">+</option>
                <option value="subtract">-</option>
                <option value="multiply">*</option>
                <option value="divide">/</option>
            </select>
            <input type="text" name="num2" placeholder="Enter a number" required>
            <button type="submit">Calculate</button>

            <p><span id="result"><?php echo $result; ?></span></p>
        </form>

        <h2> Fibonacci </h2>
        <form method="post" action="">
            <input type="text" name="fibNum" placeholder="Enter a number" required>
            <button type="submit">Calculate Fibonacci</button>

            <p><span id="fibResult"><?php echo $fibresult; ?></span></p>
        </form>

        <h2>Factorial</h2>
        <form method="post" action="">
            <input type="text" name="facNum" placeholder="Enter a number" required>
            <button type="submit">Calculate Factorial</button>
            <p><span id="facResult"><?php echo $facResult; ?></span></p>
        </form>

        <h2>Login</h2>
        <form method="post" action="">
            <label>Username:</label>
            <input type="text" name="username" placeholder="Enter a user" required>
            <label>Password:</label>
            <input type="password" name="password" placeholder="Enter the password" required>
            <button type="submit">Login</button>
            <div class="<?php echo $classState; ?>"><?php echo $logResult; ?></div>
        </form>
    </body>
</html>
