<?php
class User {
    private $username;
    private $password;

    public function __construct($user, $pass){
        $this->username = $user;
        $this->password = $pass;
    }

    public function validation(){
        if ($this->username == "admin" && $this->password == "1234"){
            return true;
        } else {
            return false;
        }

    }
}
?>