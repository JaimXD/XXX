function fibonacci(){
    const numberf = parseInt(document.getElementById("numberf").value);
    const resultElement = document.getElementById("resultf");

    if ( isNaN(numberf) || numberf < 0){
        resultElement.textContent = "Invalid input. Please enter a non-negative integer.";
        return;
    }

    const sequence = [0, 1];

    if (numberf === 0){
        sequence.length = 1;
    } else if (numberf === 1){

    } else {
        for (let i = 2; i <= numberf; i++){
            const nextFib = sequence[i - 1] + sequence[i - 2];
            sequence.push(nextFib);
        }
    }

    resultElement.textContent = sequence.join(", ");

}