function login() {

    const user = "admin";
    const pass = "123";

    const username = document.getElementById("username");
    const password = document.getElementById("password");
    const loginMessage = document.getElementById("loginMessage");

    let valuser = username.value;
    let valpass = password.value;
    
    if (valuser.trim() === "" || valpass.trim() === "") {
        loginMessage.textContent = "Please enter both username and password.";
        loginMessage.style.color = "yellow";
        return;
    }

    if (valuser === user && valpass === pass){
        loginMessage.textContent = "Login successful!";
        loginMessage.style.color = "green";
        username.style.borderColor = "green";
        password.style.borderColor = "green";
    } else {
        loginMessage.textContent = "Invalid username or password.";
        loginMessage.style.color = "red";
        username.style.borderColor = "red";
        password.style.borderColor = "red";
    }


}