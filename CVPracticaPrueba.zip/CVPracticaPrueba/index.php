<!DOCTYPE html>
<html>
<head>
    <title>Web Functions with PHP</title>
    <style>
        /* Estilos básicos para mostrar el resultado */
        .result-success { color: green; font-weight: bold; }
        .result-error { color: red; font-weight: bold; }
    </style>
</head>
<body>

<?php
// =========================================================
// 1. LÓGICA DE PROCESAMIENTO PHP
// =========================================================

// --- Variables para almacenar los resultados ---
$calc_result = "";
$fib_result = "";
$fact_result = "";
$login_message = "";
$login_user_style = "";
$login_pass_style = "";

// ---------------------------------------------------------
// PROCESAR CALCULADORA
// ---------------------------------------------------------
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['calc_submit'])) {
    $num1 = isset($_POST['number1']) ? (float)$_POST['number1'] : 0;
    $num2 = isset($_POST['number2']) ? (float)$_POST['number2'] : 0;
    $operator = $_POST['operator'] ?? 'add';

    switch ($operator) {
        case 'add':
            $calc_result = $num1 + $num2;
            break;
        case 'subtract':
            $calc_result = $num1 - $num2;
            break;
        case 'multiply':
            $calc_result = $num1 * $num2;
            break;
        case 'divide':
            if ($num2 == 0) {
                $calc_result = '<span class="result-error">Error: Division by zero</span>';
            } else {
                $calc_result = $num1 / $num2;
            }
            break;
    }
    if (!is_string($calc_result)) {
        $calc_result = '<span class="result-success">Resultado: ' . $calc_result . '</span>';
    }
}

// ---------------------------------------------------------
// PROCESAR FIBONACCI
// ---------------------------------------------------------
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['fib_submit'])) {
    $n = isset($_POST['numberf']) ? (int)$_POST['numberf'] : -1;
    $fib_result = '<span class="result-error">Invalid input. Please enter a non-negative integer.</span>';

    if ($n >= 0) {
        $sequence = [0, 1];
        if ($n === 0) {
            $sequence = [0];
        } else if ($n > 1) {
            for ($i = 2; $i <= $n; $i++) {
                $sequence[] = $sequence[$i - 1] + $sequence[$i - 2];
            }
        }
        $fib_result = '<span class="result-success">Resultado: ' . implode(', ', $sequence) . '</span>';
    }
}

// ---------------------------------------------------------
// PROCESAR FACTORIAL
// ---------------------------------------------------------
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['fact_submit'])) {
    $n = isset($_POST['numberfa']) ? (int)$_POST['numberfa'] : -1;
    $fact_result = '<span class="result-error">Invalid input. Please enter a non-negative integer.</span>';

    if ($n >= 0) {
        if ($n === 0 || $n === 1) {
            $fact = 1;
        } else {
            $fact = 1;
            for ($i = $n; $i >= 2; $i--) {
                $fact *= $i;
            }
        }
        $fact_result = '<span class="result-success">Factorial: ' . $fact . '</span>';
    }
}

// ---------------------------------------------------------
// PROCESAR LOGIN
// ---------------------------------------------------------
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['login_submit'])) {
    $user = "admin";
    $pass = "123";
    $input_user = trim($_POST['username'] ?? '');
    $input_pass = trim($_POST['password'] ?? '');

    if (empty($input_user) || empty($input_pass)) {
        $login_message = '<span style="color: yellow;">Please enter both username and password.</span>';
        $login_user_style = 'style="border-color: yellow;"';
        $login_pass_style = 'style="border-color: yellow;"';
    } elseif ($input_user === $user && $input_pass === $pass) {
        $login_message = '<span style="color: green;">Login successful!</span>';
        $login_user_style = 'style="border-color: green;"';
        $login_pass_style = 'style="border-color: green;"';
    } else {
        $login_message = '<span style="color: red;">Invalid username or password.</span>';
        $login_user_style = 'style="border-color: red;"';
        $login_pass_style = 'style="border-color: red;"';
    }
}
?>

<div>
    <h1>Simple Calculator</h1>
    <form method="POST" action="">
        <input type="number" name="number1" value="<?= $_POST['number1'] ?? '' ?>">
        <select name="operator">
            <option value="add" <?= (($_POST['operator'] ?? '') == 'add') ? 'selected' : '' ?>>+</option>
            <option value="subtract" <?= (($_POST['operator'] ?? '') == 'subtract') ? 'selected' : '' ?>>-</option>
            <option value="multiply" <?= (($_POST['operator'] ?? '') == 'multiply') ? 'selected' : '' ?>>*</option>
            <option value="divide" <?= (($_POST['operator'] ?? '') == 'divide') ? 'selected' : '' ?>>/</option>
        </select>
        <input type="number" name="number2" value="<?= $_POST['number2'] ?? '' ?>">
        <button type="submit" name="calc_submit">Calculate</button>
    </form>
    <p><?php echo $calc_result; ?></p>
</div>

---

<div>
    <h1>Fibonacci Sequence</h1>
    <form method="POST" action="">
        <input type="number" name="numberf" value="<?= $_POST['numberf'] ?? '' ?>">
        <button type="submit" name="fib_submit">Calculate</button>
    </form>
    <p><?php echo $fib_result; ?></p>
</div>

---

<div>
    <h1>Factorial Calculator</h1>
    <form method="POST" action="">
        <input type="number" name="numberfa" value="<?= $_POST['numberfa'] ?? '' ?>">
        <button type="submit" name="fact_submit">Calculate</button>
    </form>
    <p><?php echo $fact_result; ?></p>
</div>

---

<div>
    <h1>Login</h1>
    <form method="POST" action="">
        <input type="text" name="username" placeholder="Username" <?= $login_user_style ?> value="<?= $_POST['username'] ?? '' ?>">
        <input type="password" name="password" placeholder="Password" <?= $login_pass_style ?>>
        <button type="submit" name="login_submit">Login</button>
    </form>
    <p><?php echo $login_message; ?></p>
</div>

</body>
</html>