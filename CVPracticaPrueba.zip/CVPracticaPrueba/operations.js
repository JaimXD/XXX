class Calculator {
    constructor(numberOne, numberTwo){
        this.numberOne = numberOne;
        this.numberTwo  = numberTwo;
    }

    add(){
        return this.numberOne + this.numberTwo;
    }

    subtract(){
        return this.numberOne - this.numberTwo;
    }

    multiply(){
        return this.numberOne * this.numberTwo;
    }

    divide(){
        if (this.numberTwo == 0){
            return 'Error: Division by zero'
        } else {
            return this.numberOne / this.numberTwo;
        }
    }
}


function calculate (){
    const number1 = parseFloat(document.getElementById('number1').value);
    const number2 = parseFloat(document.getElementById('number2').value);
    const operation = document.getElementById('operator').value;
    let result;

    const calculator = new Calculator(number1, number2);

    switch(operation){
        case 'add':
            result = calculator.add();
            break;
        case 'subtract':
            result = calculator.subtract();
            break;
        case 'multiply':
            result = calculator.multiply();
            break;
        case 'divide':
            result = calculator.divide();
            break;
        default:
            result = 'Invalid operation';
    }

    document.getElementById('result').textContent = result;
}