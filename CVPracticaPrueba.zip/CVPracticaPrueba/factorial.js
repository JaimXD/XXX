function factorial () {
    const numberfa = parseInt(document.getElementById("numberfa").value);
    const resultElement = document.getElementById("resultfa");

    if (isNaN(numberfa) || numberfa < 0){
        resultElement.textContent = "Invalid input. Please enter a non-negative integer."; 
        return;
    }

    if ( numberfa === 0 || numberfa === 1){  
        resultElement.textContent = "Factorial: 1";
    } else {
        let fact = 1;
        for (let i = numberfa; i>=2; i--){
            fact *= i;
        }
        resultElement.textContent = "Factorial: " + fact;
    }
}