/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package ec.edu.uta.grup3.grupo03.servlets;

import ec.edu.uta.grup3.grupo03.utils.ApiClient;
import java.io.IOException;
import java.io.PrintWriter;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.UnsupportedEncodingException;
import java.net.URLDecoder;
import java.util.HashMap;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.imageio.plugins.bmp.BMPImageWriteParam;
import org.json.JSONArray;

/**
 *
 * @author User
 */
@WebServlet(name = "SvEstudiante", urlPatterns = {"/SvEstudiante"})
public class SvEstudiante extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try ( PrintWriter out = response.getWriter()) {
            /* TODO output your page here. You may use following sample code. */
            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Servlet SvEstudiante</title>");
            out.println("</head>");
            out.println("<body>");
            out.println("<h1>Servlet SvEstudiante at " + request.getContextPath() + "</h1>");
            out.println("</body>");
            out.println("</html>");
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        String action = request.getParameter("action");
        String cedula = request.getParameter("CEDULA");
        
        if ("buscar".equals(action) && cedula != null && !cedula.trim().isEmpty()) {
            JSONArray resultado = ApiClient.buscarEstudiantePorCedula(cedula);
            
            response.setContentType("application/json");
            response.setCharacterEncoding("UTF-8");
            
            response.getWriter().write(resultado.toString());
            return;
        }
        
        JSONArray estudiantes = ApiClient.getEstudiante();
        request.setAttribute("estudiantes", estudiantes);
        request.getRequestDispatcher("/index.jsp").forward(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        boolean ok = false;
        try {
            ok = ApiClient.crearEstudiante(request.getParameter("CEDULA"), request.getParameter("NOMBRE"), request.getParameter("APELLIDO"), request.getParameter("DIRECCION"), request.getParameter("TELEFONO"));
            response.setStatus(ok ? (HttpServletResponse.SC_OK) : (HttpServletResponse.SC_BAD_REQUEST));
            
            // En lugar de redireccionar, cargar los datos y forwarding
            JSONArray estudiantes = ApiClient.getEstudiante();
            request.setAttribute("estudiantes", estudiantes);
            request.getRequestDispatcher("/index.jsp").forward(request, response);
        } catch (Exception e) {
            System.out.println("Error: " + e.getMessage());
        }
    }

    @Override
    protected void doDelete(HttpServletRequest request, HttpServletResponse response) {
        try {
            boolean ok = false;
            ok = ApiClient.eliminarEstudiante(request.getParameter("CEDULA"));

            if (ok) {
                JSONArray estudiantes = ApiClient.getEstudiante();
                request.setAttribute("estudiantes", estudiantes);
            }
            response.setStatus(ok ? (HttpServletResponse.SC_OK) : (HttpServletResponse.SC_BAD_REQUEST));

        } catch (Exception e) {
            System.out.println("Error: " + e.getMessage());
        }
    }

    @Override
    protected void doPut(HttpServletRequest request, HttpServletResponse response) {
        try {
            String body = request.getReader().lines().reduce("", (acc, line) -> acc + line);
            System.out.println("Body recibido en PUT: " + body);
            Map<String, String> params = new HashMap();
            for (String pair : body.split("&")) {
                String[] keyValue = pair.split("=", 2);
                if (keyValue.length == 2) {
                    params.put(
                            URLDecoder.decode(keyValue[0], "UTF-8"),
                            URLDecoder.decode(keyValue[1], "UTF-8")
                    );
                }
            }
            boolean ok = ApiClient.editarEstudiante(
                    params.get("CEDULA"),
                    params.get("NOMBRE"),
                    params.get("APELLIDO"),
                    params.get("DIRECCION"),
                    params.get("TELEFONO")
            );

            if (ok) {
                response.setStatus(HttpServletResponse.SC_OK);
                response.getWriter().write("Estudiante actualizado exitosamente");
            } else {
                response.setStatus(HttpServletResponse.SC_BAD_REQUEST);
                response.getWriter().write("Error al actualizar estudiante");
            }

        } catch (Exception e) {
            System.out.println("Error al actualizar el estudiante: " + e.getMessage());
            try {
                response.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
                response.getWriter().write("Error interno del servidor");
            } catch (IOException ex) {
                System.out.println("Error enviando respuesta: " + ex.getMessage());

            }
        }
    }

        /**
         * Returns a short description of the servlet.
         *
         * @return a String containing servlet description
         */
        @Override
        public String getServletInfo
        
            () {
        return "Short description";
        }// </editor-fold>

}