/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ec.edu.uta.grup3.grupo03.utils;

import jakarta.ws.rs.DELETE;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URI;
import java.net.URL;
import java.net.URLEncoder;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.net.http.HttpResponse.BodyHandlers;
import java.util.logging.Level;
import java.util.logging.Logger;
import org.json.JSONArray;
import org.json.JSONObject;

/**
 *
 * @author Alejandro Falcon
 */
public class ApiClient {

    private static final String API_URL = "http://localhost/SOA_APIX/api.php";
    private static final HttpClient HTTP = HttpClient.newHttpClient();

    public static JSONArray getEstudiante() {
        try {
            URL url = new URL(API_URL);
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("GET");
            conn.setRequestProperty("Accept", "application/json");

            //leer http
            InputStreamReader lector = new InputStreamReader(conn.getInputStream(), "UTF-8");
            BufferedReader br = new BufferedReader(lector);
            StringBuilder sb = new StringBuilder();
            //String linea+;

            String linea;
            while ((linea = br.readLine()) != null) {
                sb.append(linea);
            }
            //cerrar conexion y liberara recursos
            br.close();
            lector.close();
            conn.disconnect();
            return new JSONArray(sb.toString());
        } catch (Exception ex) {
            Logger.getLogger(ApiClient.class.getName()).log(Level.SEVERE, null, ex);
        }
        return null;
    }

    public static boolean crearEstudiante(String CEDULA, String NOMBRE, String APELLIDO, String DIRECCION, String TELEFONO) {
        try {
            String parametros = parametrosCompletos(CEDULA, NOMBRE, APELLIDO, DIRECCION, TELEFONO);
            HttpRequest req = (HttpRequest) HttpRequest.newBuilder(new URI(API_URL))
                    .header("Content-Type", "application/x-www-form-urlencoded")
                    .POST(HttpRequest.BodyPublishers.ofString(parametros))
                    .build();

            HttpResponse<String> resp = HTTP.send(req, BodyHandlers.ofString());
            return (resp.statusCode()) == 200;

        } catch (Exception e) {
            return false;
        }

    }

    private static String parametrosCompletos(String CEDULA, String NOMBRE, String APELLIDO, String DIRECCION, String TELEFONO) throws Exception {
        return "CEDULA=" + URLEncoder.encode(CEDULA, "UTF-8") + 
        "&NOMBRE=" + URLEncoder.encode(NOMBRE, "UTF-8") + 
        "&APELLIDO=" + URLEncoder.encode(APELLIDO, "UTF-8") + 
        "&DIRECCION=" + URLEncoder.encode(DIRECCION, "UTF-8") + 
        "&TELEFONO=" + URLEncoder.encode(TELEFONO, "UTF-8");
    }

    public static boolean eliminarEstudiante(String CEDULA) {
        try {
            String url = API_URL + "?CEDULA=" + CEDULA;
            HttpRequest req = HttpRequest.newBuilder(URI.create(url))
                    .DELETE()
                    .header("Accept", "application/json")
                    .build();
            HttpResponse<String> resp = HTTP.send(req, HttpResponse.BodyHandlers.ofString());
            return (resp.statusCode()) == 200;
        } catch (Exception e) {
            return false;
        }

    }

    public static boolean editarEstudiante(String CEDULA, String NOMBRE, String APELLIDO, String DIRECCION, String TELEFONO) {
        try {
            // Construir los parámetros para la URL
            String parametros = parametrosCompletos(CEDULA, NOMBRE, APELLIDO, DIRECCION, TELEFONO);
            String urlCompleta = API_URL + "?" + parametros;

            HttpRequest req = HttpRequest.newBuilder()
                    .uri(new URI(urlCompleta))
                    .PUT(HttpRequest.BodyPublishers.noBody())
                    .build();

            HttpResponse<String> resp = HttpClient.newHttpClient().send(req, HttpResponse.BodyHandlers.ofString());
            return (resp.statusCode() == 200);

        } catch (Exception e) {
            System.out.println("Error en actualizarEstudiante: " + e.getMessage());
            return false;
        }
    }

    
    public static JSONArray buscarEstudiantePorCedula(String CEDULA) {
        try {
            String urlCompleta = API_URL + "?CEDULA=" + URLEncoder.encode(CEDULA, "UTF-8");
            System.out.println("URL de búsqueda: " + urlCompleta); 
            
            URL url = new URL(urlCompleta);
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("GET");
            conn.setRequestProperty("Accept", "application/json");
            conn.setConnectTimeout(5000);
            conn.setReadTimeout(5000);

            int responseCode = conn.getResponseCode();
            System.out.println("Código de respuesta: " + responseCode); 
            
            if (responseCode == 200) {
                InputStreamReader lector = new InputStreamReader(conn.getInputStream(), "UTF-8");
                BufferedReader br = new BufferedReader(lector);
                StringBuilder sb = new StringBuilder();

                String linea;
                while ((linea = br.readLine()) != null) {
                    sb.append(linea);
                }

                br.close();
                lector.close();
                conn.disconnect();

                String response = sb.toString();
                System.out.println("Respuesta de la API: " + response); 
                
                if (response == null || response.trim().isEmpty() || response.equals("null") || response.equals("[]")) {
                    System.out.println("Respuesta vacía, retornando array vacío");
                    return new JSONArray();
                }
                
                if (response.trim().startsWith("{")) {
                    JSONArray result = new JSONArray();
                    result.put(new JSONObject(response));
                    System.out.println("Convertido objeto a array: " + result.toString());
                    return result;
                }
                
                JSONArray result = new JSONArray(response);
                System.out.println("Retornando array directamente: " + result.toString());
                return result;
            } else {
                System.out.println("Error en la búsqueda. Código de respuesta: " + responseCode);
                
                if (conn.getErrorStream() != null) {
                    InputStreamReader errorReader = new InputStreamReader(conn.getErrorStream(), "UTF-8");
                    BufferedReader errorBuffer = new BufferedReader(errorReader);
                    StringBuilder errorMsg = new StringBuilder();
                    String errorLine;
                    while ((errorLine = errorBuffer.readLine()) != null) {
                        errorMsg.append(errorLine);
                    }
                    System.out.println("Mensaje de error: " + errorMsg.toString());
                    errorBuffer.close();
                    errorReader.close();
                }
                
                return new JSONArray(); 
            }
        } catch (Exception ex) {
            System.out.println("Error al buscar estudiante por cédula: " + ex.getMessage());
            ex.printStackTrace();
            Logger.getLogger(ApiClient.class.getName()).log(Level.SEVERE, null, ex);
            return new JSONArray(); 
        }
    }
}