# API RESTful General - Documentación

## Descripción
API RESTful flexible que funciona con cualquier tabla de la base de datos. Soporta operaciones CRUD completas y es compatible con cualquier programa cliente (Web, Móvil, Escritorio, etc.).

## Características
✅ Operaciones CRUD completas (Create, Read, Update, Delete)
✅ Paginación y filtros avanzados
✅ CORS habilitado para acceso desde cualquier origen
✅ Respuestas en JSON
✅ Manejo de errores robusto
✅ Compatible con cualquier tabla de la base de datos

## Configuración

Editar las credenciales en `Connection.php`:
```php
private $host = 'localhost';
private $db_name = 'cv';        // Tu base de datos
private $db_user = 'root';
private $db_pass = '';
```

## Endpoints

La API funciona con la estructura: `http://localhost/API_GENERAL/Api.php?path=tabla[/id]`

### 1. GET - Obtener todos los registros
```
GET http://localhost/API_GENERAL/Api.php?path=estudiantes
```

**Respuesta:**
```json
{
  "success": true,
  "data": [
    {
      "cedula": "1758901234",
      "nombre": "Carlos",
      "apellido": "Pérez",
      "direccion": "Av Los Andes 123",
      "telefono": "0087654321"
    }
  ],
  "total": 10
}
```

### 2. GET - Con paginación
```
GET http://localhost/API_GENERAL/Api.php?path=estudiantes&limit=5&offset=0
```

### 3. GET - Con filtros
```
GET http://localhost/API_GENERAL/Api.php?path=estudiantes&nombre=Carlos&apellido=Pérez
```

### 4. GET - Obtener un registro específico
```
GET http://localhost/API_GENERAL/Api.php?path=estudiantes/1
```

**Respuesta:**
```json
{
  "success": true,
  "data": {
    "cedula": "1758901234",
    "nombre": "Carlos",
    "apellido": "Pérez",
    "direccion": "Av Los Andes 123",
    "telefono": "0087654321"
  }
}
```

### 5. POST - Crear nuevo registro
```
POST http://localhost/API_GENERAL/Api.php?path=estudiantes
Content-Type: application/json

{
  "cedula": "1234567890",
  "nombre": "Juan",
  "apellido": "García",
  "direccion": "Calle Principal 456",
  "telefono": "0987654321"
}
```

**Respuesta:**
```json
{
  "success": true,
  "message": "Registro creado exitosamente",
  "id": 12
}
```

### 6. PUT - Actualizar un registro
```
PUT http://localhost/API_GENERAL/Api.php?path=estudiantes/1
Content-Type: application/json

{
  "nombre": "Carlos",
  "apellido": "López",
  "telefono": "0987654322"
}
```

**Respuesta:**
```json
{
  "success": true,
  "message": "Registro actualizado exitosamente"
}
```

### 7. DELETE - Eliminar un registro
```
DELETE http://localhost/API_GENERAL/Api.php?path=estudiantes/1
```

**Respuesta:**
```json
{
  "success": true,
  "message": "Registro eliminado exitosamente"
}
```

## Ejemplos de Uso en Diferentes Lenguajes

### JavaScript (Fetch API)
```javascript
// GET
fetch('http://localhost/API_GENERAL/Api.php?path=estudiantes')
  .then(res => res.json())
  .then(data => console.log(data));

// POST
fetch('http://localhost/API_GENERAL/Api.php?path=estudiantes', {
  method: 'POST',
  headers: { 'Content-Type': 'application/json' },
  body: JSON.stringify({
    cedula: '1234567890',
    nombre: 'Juan',
    apellido: 'García',
    direccion: 'Calle Principal 456',
    telefono: '0987654321'
  })
})
.then(res => res.json())
.then(data => console.log(data));

// PUT
fetch('http://localhost/API_GENERAL/Api.php?path=estudiantes/1', {
  method: 'PUT',
  headers: { 'Content-Type': 'application/json' },
  body: JSON.stringify({
    nombre: 'Juan actualizado',
    apellido: 'García actualizado'
  })
})
.then(res => res.json())
.then(data => console.log(data));

// DELETE
fetch('http://localhost/API_GENERAL/Api.php?path=estudiantes/1', {
  method: 'DELETE'
})
.then(res => res.json())
.then(data => console.log(data));
```

### Python (requests)
```python
import requests
import json

# GET
response = requests.get('http://localhost/API_GENERAL/Api.php?path=estudiantes')
print(response.json())

# POST
data = {
    'cedula': '1234567890',
    'nombre': 'Juan',
    'apellido': 'García',
    'direccion': 'Calle Principal 456',
    'telefono': '0987654321'
}
response = requests.post('http://localhost/API_GENERAL/Api.php?path=estudiantes', json=data)
print(response.json())

# PUT
data = {'nombre': 'Juan actualizado'}
response = requests.put('http://localhost/API_GENERAL/Api.php?path=estudiantes/1', json=data)
print(response.json())

# DELETE
response = requests.delete('http://localhost/API_GENERAL/Api.php?path=estudiantes/1')
print(response.json())
```

### cURL (Terminal)
```bash
# GET
curl http://localhost/API_GENERAL/Api.php?path=estudiantes

# POST
curl -X POST http://localhost/API_GENERAL/Api.php?path=estudiantes \
  -H "Content-Type: application/json" \
  -d '{"cedula":"1234567890","nombre":"Juan","apellido":"García"}'

# PUT
curl -X PUT http://localhost/API_GENERAL/Api.php?path=estudiantes/1 \
  -H "Content-Type: application/json" \
  -d '{"nombre":"Juan actualizado"}'

# DELETE
curl -X DELETE http://localhost/API_GENERAL/Api.php?path=estudiantes/1
```

### PHP
```php
// GET
$response = file_get_contents('http://localhost/API_GENERAL/Api.php?path=estudiantes');
$data = json_decode($response, true);
print_r($data);

// POST
$data = [
    'cedula' => '1234567890',
    'nombre' => 'Juan',
    'apellido' => 'García'
];

$options = [
    'http' => [
        'header'  => "Content-type: application/json\r\n",
        'method'  => 'POST',
        'content' => json_encode($data)
    ]
];

$context = stream_context_create($options);
$response = file_get_contents('http://localhost/API_GENERAL/Api.php?path=estudiantes', false, $context);
$result = json_decode($response, true);
print_r($result);
```

## Códigos de Estado HTTP

| Código | Significado |
|--------|-------------|
| 200 | OK - Solicitud exitosa |
| 400 | Bad Request - Datos inválidos |
| 405 | Method Not Allowed - Método HTTP no permitido |
| 500 | Internal Server Error - Error del servidor |

## Notas Importantes

- La API usa PDO para seguridad contra inyección SQL
- CORS está habilitado para acceso desde cualquier origen
- Todos los registros deben tener una columna `id` como clave primaria
- Las respuestas siempre incluyen un campo `success` indicando si la operación fue exitosa
- Los filtros en GET se aplican con búsqueda parcial (LIKE)

## Seguridad

Para producción, considera:
- Implementar autenticación (JWT, OAuth)
- Validar y sanitizar inputs
- Limitar CORS a dominios específicos
- Usar HTTPS
- Implementar rate limiting
- Agregar logging de accesos

---

**¡Tu API está lista para ser usada por cualquier programa!**
