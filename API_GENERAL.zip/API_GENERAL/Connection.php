<?php
/**
 * Clase de Conexión a la Base de Datos
 * Maneja la conexión a MySQL usando PDO
 */
class Connection {
    private $host = 'localhost';
    private $db_name = 'cv';
    private $db_user = 'root';
    private $db_pass = '';
    private $charset = 'utf8mb4';
    
    private $pdo;

    /**
     * Constructor - Establece la conexión
     */
    public function __construct() {
        $this->connect();
    }

    /**
     * Conecta a la base de datos usando PDO
     */
    private function connect() {
        try {
            $dsn = "mysql:host={$this->host};dbname={$this->db_name};charset={$this->charset}";
            $this->pdo = new PDO($dsn, $this->db_user, $this->db_pass);
            $this->pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        } catch (PDOException $e) {
            die(json_encode([
                'success' => false,
                'message' => 'Error de conexión: ' . $e->getMessage()
            ]));
        }
    }

    /**
     * Retorna la conexión PDO
     */
    public function getConnection() {
        return $this->pdo;
    }

    /**
     * Ejecuta una consulta preparada
     */
    public function executeQuery($query, $params = []) {
        try {
            $stmt = $this->pdo->prepare($query);
            $stmt->execute($params);
            return $stmt;
        } catch (PDOException $e) {
            throw new Exception('Error en la consulta: ' . $e->getMessage());
        }
    }
}
?>
