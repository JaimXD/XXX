<?php
/**
 * API RESTful Principal
 * Maneja todas las solicitudes HTTP (GET, POST, PUT, DELETE)
 * Compatible con cualquier cliente (Web, Móvil, Escritorio)
 */

// Configurar headers CORS para permitir acceso desde cualquier origen
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization');
header('Content-Type: application/json; charset=utf-8');

// Importar clases
require_once 'Connection.php';
require_once 'Crud.php';

// Crear instancia de conexión
$connection = new Connection();

// Obtener método HTTP
$method = $_SERVER['REQUEST_METHOD'];

// Obtener ruta solicitada
$path = isset($_GET['path']) ? $_GET['path'] : '';
$parts = explode('/', trim($path, '/'));

// Tabla solicitada (primer parámetro de la ruta)
$table = isset($parts[0]) ? $parts[0] : '';

// ID del registro (segundo parámetro de la ruta)
$id = isset($parts[1]) ? $parts[1] : null;

// Obtener cuerpo JSON
$data = json_decode(file_get_contents("php://input"), true);

// Respuesta por defecto
$response = [
    'success' => false,
    'message' => 'Solicitud inválida'
];

try {
    // Validar que se especificó una tabla
    if (empty($table)) {
        http_response_code(400);
        echo json_encode([
            'success' => false,
            'message' => 'Debe especificar una tabla en la ruta (ej: ?path=estudiantes)'
        ]);
        exit;
    }

    // Crear instancia CRUD
    $crud = new Crud($connection, $table);

    // Procesar según el método HTTP
    switch ($method) {
        case 'GET':
            $response = handleGET($crud, $id, $table);
            break;

        case 'POST':
            $response = handlePOST($crud, $data, $table);
            break;

        case 'PUT':
            $response = handlePUT($crud, $id, $data, $table);
            break;

        case 'DELETE':
            $response = handleDELETE($crud, $id, $table);
            break;

        case 'OPTIONS':
            http_response_code(200);
            exit;

        default:
            http_response_code(405);
            $response = [
                'success' => false,
                'message' => 'Método HTTP no permitido'
            ];
    }

} catch (Exception $e) {
    http_response_code(500);
    $response = [
        'success' => false,
        'message' => 'Error del servidor: ' . $e->getMessage()
    ];
}

// Enviar respuesta
echo json_encode($response, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);

/**
 * Maneja solicitudes GET
 */
function handleGET($crud, $id, $table) {
    if ($id) {
        // Obtener un registro específico
        return $crud->readById($id);
    } else {
        // Obtener todos los registros con paginación
        $limit = isset($_GET['limit']) ? (int)$_GET['limit'] : null;
        $offset = isset($_GET['offset']) ? (int)$_GET['offset'] : 0;
        
        // Aplicar filtros si existen
        $filters = [];
        foreach ($_GET as $key => $value) {
            if (!in_array($key, ['path', 'limit', 'offset']) && !empty($value)) {
                $filters[$key] = $value;
            }
        }
        
        if (!empty($filters)) {
            return $crud->readWithFilters($filters, $limit, $offset);
        } else {
            $data = $crud->readAll($limit, $offset);
            $data['total'] = $crud->count();
            return $data;
        }
    }
}

/**
 * Maneja solicitudes POST (Crear nuevo registro)
 */
function handlePOST($crud, $data, $table) {
    if (!$data || empty($data)) {
        http_response_code(400);
        return [
            'success' => false,
            'message' => 'Debe enviar datos en formato JSON'
        ];
    }

    return $crud->create($data);
}

/**
 * Maneja solicitudes PUT (Actualizar registro)
 */
function handlePUT($crud, $id, $data, $table) {
    if (!$id) {
        http_response_code(400);
        return [
            'success' => false,
            'message' => 'Debe especificar un ID en la ruta (ej: ?path=estudiantes/1)'
        ];
    }

    if (!$data || empty($data)) {
        http_response_code(400);
        return [
            'success' => false,
            'message' => 'Debe enviar datos en formato JSON'
        ];
    }

    return $crud->update($id, $data);
}

/**
 * Maneja solicitudes DELETE (Eliminar registro)
 */
function handleDELETE($crud, $id, $table) {
    if (!$id) {
        http_response_code(400);
        return [
            'success' => false,
            'message' => 'Debe especificar un ID en la ruta (ej: ?path=estudiantes/1)'
        ];
    }

    return $crud->delete($id);
}
?>
