<?php
/**
 * Clase CRUD Genérica para todas las tablas
 * Permite operaciones básicas (Create, Read, Update, Delete)
 */
class Crud {
    private $connection;
    private $table;

    public function __construct($connection, $table) {
        $this->connection = $connection->getConnection();
        $this->table = $table;
    }

    /**
     * CREATE - Insertar un nuevo registro
     * @param array $data Datos a insertar
     * @return array Respuesta con éxito o error
     */
    public function create($data) {
        try {
            $columns = implode(',', array_keys($data));
            $placeholders = implode(',', array_fill(0, count($data), '?'));
            
            $query = "INSERT INTO {$this->table} ({$columns}) VALUES ({$placeholders})";
            $stmt = $this->connection->prepare($query);
            
            $result = $stmt->execute(array_values($data));
            
            return [
                'success' => true,
                'message' => 'Registro creado exitosamente',
                'id' => $this->connection->lastInsertId()
            ];
        } catch (Exception $e) {
            return [
                'success' => false,
                'message' => 'Error al crear el registro: ' . $e->getMessage()
            ];
        }
    }

    /**
     * READ - Obtener todos los registros
     * @param int $limit Límite de registros
     * @param int $offset Desplazamiento
     * @return array Registros obtenidos
     */
    public function readAll($limit = null, $offset = 0) {
        try {
            $query = "SELECT * FROM {$this->table}";
            
            if ($limit) {
                $query .= " LIMIT {$limit} OFFSET {$offset}";
            }
            
            $stmt = $this->connection->prepare($query);
            $stmt->execute();
            
            return [
                'success' => true,
                'data' => $stmt->fetchAll(PDO::FETCH_ASSOC)
            ];
        } catch (Exception $e) {
            return [
                'success' => false,
                'message' => 'Error al obtener registros: ' . $e->getMessage()
            ];
        }
    }

    /**
     * READ - Obtener un registro por ID
     * @param int $id ID del registro
     * @return array Registro obtenido
     */
    public function readById($id) {
        try {
            $query = "SELECT * FROM {$this->table} WHERE id = ?";
            $stmt = $this->connection->prepare($query);
            $stmt->execute([$id]);
            
            $data = $stmt->fetch(PDO::FETCH_ASSOC);
            
            if (!$data) {
                return [
                    'success' => false,
                    'message' => 'Registro no encontrado'
                ];
            }
            
            return [
                'success' => true,
                'data' => $data
            ];
        } catch (Exception $e) {
            return [
                'success' => false,
                'message' => 'Error al obtener el registro: ' . $e->getMessage()
            ];
        }
    }

    /**
     * READ - Obtener registros con filtros
     * @param array $filters Filtros a aplicar
     * @param int $limit Límite de registros
     * @param int $offset Desplazamiento
     * @return array Registros que coinciden con los filtros
     */
    public function readWithFilters($filters = [], $limit = null, $offset = 0) {
        try {
            $query = "SELECT * FROM {$this->table}";
            $conditions = [];
            $params = [];
            
            if (!empty($filters)) {
                foreach ($filters as $column => $value) {
                    $conditions[] = "{$column} LIKE ?";
                    $params[] = "%{$value}%";
                }
                
                if (!empty($conditions)) {
                    $query .= " WHERE " . implode(" AND ", $conditions);
                }
            }
            
            if ($limit) {
                $query .= " LIMIT {$limit} OFFSET {$offset}";
            }
            
            $stmt = $this->connection->prepare($query);
            $stmt->execute($params);
            
            return [
                'success' => true,
                'data' => $stmt->fetchAll(PDO::FETCH_ASSOC)
            ];
        } catch (Exception $e) {
            return [
                'success' => false,
                'message' => 'Error en la búsqueda: ' . $e->getMessage()
            ];
        }
    }

    /**
     * UPDATE - Actualizar un registro
     * @param int $id ID del registro
     * @param array $data Datos a actualizar
     * @return array Respuesta con éxito o error
     */
    public function update($id, $data) {
        try {
            $columns = [];
            $values = [];
            
            foreach ($data as $column => $value) {
                $columns[] = "{$column} = ?";
                $values[] = $value;
            }
            
            $values[] = $id;
            
            $query = "UPDATE {$this->table} SET " . implode(',', $columns) . " WHERE id = ?";
            $stmt = $this->connection->prepare($query);
            $result = $stmt->execute($values);
            
            return [
                'success' => true,
                'message' => 'Registro actualizado exitosamente'
            ];
        } catch (Exception $e) {
            return [
                'success' => false,
                'message' => 'Error al actualizar el registro: ' . $e->getMessage()
            ];
        }
    }

    /**
     * DELETE - Eliminar un registro
     * @param int $id ID del registro
     * @return array Respuesta con éxito o error
     */
    public function delete($id) {
        try {
            $query = "DELETE FROM {$this->table} WHERE id = ?";
            $stmt = $this->connection->prepare($query);
            $result = $stmt->execute([$id]);
            
            return [
                'success' => true,
                'message' => 'Registro eliminado exitosamente'
            ];
        } catch (Exception $e) {
            return [
                'success' => false,
                'message' => 'Error al eliminar el registro: ' . $e->getMessage()
            ];
        }
    }

    /**
     * Obtener el total de registros
     * @return int Total de registros
     */
    public function count() {
        try {
            $query = "SELECT COUNT(*) as total FROM {$this->table}";
            $stmt = $this->connection->prepare($query);
            $stmt->execute();
            
            $result = $stmt->fetch(PDO::FETCH_ASSOC);
            return $result['total'];
        } catch (Exception $e) {
            return 0;
        }
    }
}
?>
