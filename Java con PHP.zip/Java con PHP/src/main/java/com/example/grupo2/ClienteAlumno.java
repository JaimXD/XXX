package com.example.grupo2;

import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.util.List;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import com.google.gson.Gson;
import java.io.IOException;
import java.util.ArrayList;

public class ClienteAlumno {

    private final Gson conversorJson = new Gson();
    private final HttpClient clienteHttp = HttpClient.newHttpClient();
    private final String direccionBase = "http://127.0.0.1:8000/api"; // apunta a /api de Laravel

    // obtener todos los alumnos
    public List<Alumno> obtenerAlumnos() throws Exception {
        URI uri = URI.create(direccionBase);
        HttpRequest request = HttpRequest.newBuilder(uri).GET().build();
        HttpResponse<String> response = clienteHttp.send(request, HttpResponse.BodyHandlers.ofString());

        Alumno[] alumnos = conversorJson.fromJson(response.body(), Alumno[].class);
        return List.of(alumnos);
    }

    // obtener un alumno por cedula
    public Alumno obtenerPorCedula(String cedula) throws Exception {
        HttpRequest peticion = HttpRequest.newBuilder()
                .uri(URI.create(direccionBase + "/" + cedula)) 
                .GET()
                .build();
        HttpResponse<String> respuesta = clienteHttp.send(peticion, HttpResponse.BodyHandlers.ofString());
         if (respuesta.statusCode() != 201 && respuesta.statusCode() != 200) {
             System.out.println(respuesta.body());
             return null;
         }
        return conversorJson.fromJson(respuesta.body(), Alumno.class);
    }

    //crear un alumno
    public String registarAlumno(Alumno alumno) throws Exception {
        String cuerpoJson = conversorJson.toJson(alumno);
        HttpRequest peticion = HttpRequest.newBuilder()
                .uri(URI.create(direccionBase))
                .header("Content-Type", "application/json")
                .POST(HttpRequest.BodyPublishers.ofString(cuerpoJson))
                .build();
        HttpResponse<String> respuesta = clienteHttp.send(peticion, HttpResponse.BodyHandlers.ofString());

        if (respuesta.statusCode() != 201 && respuesta.statusCode() != 200) {
            return "No se pudo registrar al alumno";
        }
        return "Alumno registrado correctamente";
    }

    // actualizar un alumno ya existente
    public String editarAlumno(Alumno alumno) throws Exception {
        if (alumno.getId() == 0) {
            throw new RuntimeException("El alumno debe tener un ID para actualizarse");
        }

        String cuerpoJson = conversorJson.toJson(alumno);
        HttpRequest peticion = HttpRequest.newBuilder()
                .uri(URI.create(direccionBase + "/" + alumno.getId()))
                .header("Content-Type", "application/json")
                .PUT(HttpRequest.BodyPublishers.ofString(cuerpoJson))
                .build();

        HttpResponse<String> respuesta = clienteHttp.send(peticion, HttpResponse.BodyHandlers.ofString());
        if (respuesta.statusCode() != 200) {
            return "Alumno no se pudo actulaizar";
        }
        return "Alumno actulizado correctamente";
    }

    // eliminar un alumno segun su id
    public String eliminarAlumno(String id) throws Exception {
        HttpRequest peticion = HttpRequest.newBuilder()
                .uri(URI.create(direccionBase + "/" + id))
                .DELETE()
                .build();

        HttpResponse<String> respuesta = clienteHttp.send(peticion, HttpResponse.BodyHandlers.ofString());
        if (respuesta.statusCode() != 200) {
            return "No se pudo eliminar al alumno";
        }
        return "Alumno eliminado correctamente";
    }

    // agregar un nuevo alumno (alternativa con retorno)
    public String crearAlumno(Alumno alumno) throws Exception {
        String cuerpoJson = conversorJson.toJson(alumno);

        HttpRequest peticion = HttpRequest.newBuilder()
                .uri(URI.create(direccionBase))
                .header("Content-Type", "application/json")
                .POST(HttpRequest.BodyPublishers.ofString(cuerpoJson))
                .build();

        HttpResponse<String> respuesta = clienteHttp.send(peticion, HttpResponse.BodyHandlers.ofString());
          if (respuesta.statusCode() != 200) {
            return "No se pudo crear correctamente al alumno";
        }
        return "Alumno creado correctamente";
    }

    // actualizar un alumno ya existente (alternativa con retorno)
    public String actualizarAlumno(Alumno alumno) throws Exception {

        String cuerpoJson = conversorJson.toJson(alumno);

        HttpRequest peticion = HttpRequest.newBuilder()
                .uri(URI.create(direccionBase + "/" + alumno.getCedula()))
                .header("Content-Type", "application/json")
                .PUT(HttpRequest.BodyPublishers.ofString(cuerpoJson))
                .build();

        HttpResponse<String> respuesta = clienteHttp.send(peticion, HttpResponse.BodyHandlers.ofString());
        return respuesta.body();
    }
}
